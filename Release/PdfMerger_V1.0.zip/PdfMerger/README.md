# PDF_pack
PDF Dateien mergen
* PDF Dateien einzeln oder ganzen Ordern auswählen
* PDF nach Name sortieren
* PDF zusammenführen in eine einzelne Datei
* PDF auf Desktop speichern
